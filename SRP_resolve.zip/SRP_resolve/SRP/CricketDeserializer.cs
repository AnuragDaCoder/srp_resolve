﻿// See https://aka.ms/new-console-template for more information

using Newtonsoft.Json;
using System.Xml.Serialization;

public class CricketDeserializer
{
    public List<CricketRating> cricketRatingDeserializeJson(string sourceJson)
    {
        return JsonConvert.DeserializeObject<List<CricketRating>>(sourceJson);
    }

    public List<CricketRating> cricketRatingDeserializeXml(string sourceXml)
    {
        return DeserializeToObject<List<CricketRating>>(sourceXml);
    }

    public T DeserializeToObject<T>(string filepath) where T : class
    {
        XmlSerializer ser = new XmlSerializer(typeof(T));

        using (StreamReader sr = new StreamReader(filepath))
        {
            return (T)ser.Deserialize(sr);
        }
    }

    public T SerializeXml<T>(string filepath, T result) where T : class
    {
        XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));

        using (FileStream stream = File.Create(filepath))
        {
            xmlSerializer.Serialize(stream, result);
        }
        return result;
    }
}