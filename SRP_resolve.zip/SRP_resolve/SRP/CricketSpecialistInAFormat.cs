﻿// See https://aka.ms/new-console-template for more information

using SRP;

internal class CricketSpecialistInAFormat
{
    public Logger Logger { get; set; } = new Logger();
    public CricketRatingSource sourceObj = new ();
    public CricketDeserializer cricketDeserializerObj = new();
    public int OverAllRating { get; set; }

    internal void OverAllRate(Source source)
    {
        List<CricketRating> ratingObject = new();
        if(Source.JSON == source)
        {
            var ratingJsonStr = sourceObj.CricketRatingFromJson();
            ratingObject = cricketDeserializerObj.cricketRatingDeserializeJson(ratingJsonStr); ;

        }
        else if (Source.XML == source)
        {
            var ratingXMLStr = sourceObj.CricketRatingFromXML();
            ratingObject = cricketDeserializerObj.cricketRatingDeserializeXml(ratingXMLStr);
        }
        
        foreach (var item in ratingObject)
        {
            Logger.Log("-----------------------------");
            Enum.TryParse(item.Format, out CricketFormat format);
            switch (format)
            {
                case CricketFormat.T20:
                    Logger.Log("T20 Format");

                    if (item.StrikeRate > 150 && item.Average > 40)
                    {
                        Logger.Log($"star player:: {item.Name}");
                        Logger.Log("Applicable for special bonus");
                    }
                    else
                    {
                        Logger.Log($"Average player:: {item.Name}");
                        Logger.Log("player will be given next 10 chances to prove");
                        Logger.Log("Not applicable for bonus");
                    }
                    break;
                case CricketFormat.ODI:
                    Logger.Log("ODI Format");
                    if (item.StrikeRate > 95)
                    {
                        Logger.Log($"star player:: {item.Name}");
                        Logger.Log("Applicable for special bonus");
                    }
                    else
                    {
                        Logger.Log($"Average player:: {item.Name}");
                        Logger.Log("Not applicable for bonus");
                    }
                    break;
                default:
                    Logger.Log("unknown format!!");
                    break;
            } 
        }
    }
}